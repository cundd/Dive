//
//  CunddArray.h
//  CunddIBKit
//
//  Created by Daniel Corn on 10.06.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CunddArray : NSArray {
	NSMutableArray * _internalArray;
}

@end
