//
//  CunddChoserController.h
//
//  Created by Daniel Corn on 25.05.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface CunddChoserController : NSArrayController {
	NSArray * content;
}

@end
