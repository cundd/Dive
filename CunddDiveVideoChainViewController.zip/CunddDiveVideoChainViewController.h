//
//  CunddDiveVideoChainViewController.h
//  Dive
//
//  Created by Daniel Corn on 22.04.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CunddViewController.h"
#import "CunddDiveVideoChainSettings.h"
#import "CunddDiveVideoChainCollectionController.h"
#import "CunddDiveVideoChainDraggingDestinationView.h"
#import "CunddDiveVideoChainQCPatchController.h"
#import <Quartz/Quartz.h>


@interface CunddDiveVideoChainViewController : CunddViewController {
	IBOutlet CunddDiveVideoChainCollectionController * vcSettingsController;
	IBOutlet CunddDiveVideoChainSettings * vcSettings;
	IBOutlet NSObjectController * inputController;
	IBOutlet id qcController;
	IBOutlet NSNumber * index;
	IBOutlet QCView * previewView;
	IBOutlet CunddDiveVideoChainQCPatchController * vcQCPatchController;
}

@property (retain) CunddDiveVideoChainCollectionController * vcSettingsController;
@property (retain) CunddDiveVideoChainSettings * vcSettings;
@property (retain) id qcController;
@property (retain,readonly) NSNumber * index;
@property (retain) NSObjectController * inputController;
@property (retain) QCView * previewView;
@property (retain) CunddDiveVideoChainQCPatchController * vcQCPatchController;

@end
