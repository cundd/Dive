//
//  CunddDiveVideoChainViewController.h
//  Dive
//
//  Created by Daniel Corn on 22.04.10.
//
//    Copyright © 2010-2012 Corn Daniel
//
//    This file is part of Dive.
//
//    Dive is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    Foobar is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
//
//

#import <Cocoa/Cocoa.h>
#import "CunddViewController.h"
#import "CunddDiveVideoChainSettings.h"
#import "CunddDiveVideoChainCollectionController.h"
#import "CunddDiveVideoChainDraggingDestinationView.h"
#import "CunddDiveVideoChainQCPatchController.h"
#import <Quartz/Quartz.h>


@interface CunddDiveVideoChainViewController : CunddViewController {
	IBOutlet CunddDiveVideoChainCollectionController * vcSettingsController;
	IBOutlet CunddDiveVideoChainSettings * vcSettings;
	IBOutlet NSObjectController * inputController;
	IBOutlet id qcController;
	IBOutlet NSNumber * index;
	IBOutlet QCView * previewView;
	IBOutlet CunddDiveVideoChainQCPatchController * vcQCPatchController;
}

@property (retain) CunddDiveVideoChainCollectionController * vcSettingsController;
@property (retain) CunddDiveVideoChainSettings * vcSettings;
@property (retain) id qcController;
@property (retain,readonly) NSNumber * index;
@property (retain) NSObjectController * inputController;
@property (retain) QCView * previewView;
@property (retain) CunddDiveVideoChainQCPatchController * vcQCPatchController;

@end
