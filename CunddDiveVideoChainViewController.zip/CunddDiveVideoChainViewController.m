//
//  CunddDiveVideoChainViewController.m
//  Dive
//
//  Created by Daniel Corn on 22.04.10.
//
//    Copyright © 2010-2012 Corn Daniel
//
//    This file is part of Dive.
//
//    Dive is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    Foobar is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
//
//

#import "CunddDiveVideoChainViewController.h"


@implementation CunddDiveVideoChainViewController

/*!
    @method     
    @abstract   Bind to the QCPatchController
    @discussion Automatically binds the settings-object to the QCPatchController (if it is defined)
*/

-(void) loadView{
	[super loadView];
	
	// Get the settings-object
	if(!self.vcSettings){
		self.vcSettings = [vcSettingsController objectAtIndex:[self.index intValue]];
	}
	
	
	// Set the Quartz-Composer-File
	//[self.qcController loa]
	
	//Load the composition file into the QCView (because this QCView is bound to a QCPatchController in the nib file, this will actually update the QCPatchController along with all the bindings)
/*	if(![view loadCompositionFromFile:[[NSBundle mainBundle] pathForResource:@"Chart" ofType:@"qtz"]]) {
		NSLog(@"Composition loading failed");
		[NSApp terminate:nil];
	}
 // */
	
	
	// Set the settings-object of the view
	[self.view setVcSettings:self.vcSettings];
	self.vcSettings.retain;
	
	// Bind to the QCPatchController
	NSArray * bindingKeys = [CunddConfig valueForKeyPath:@"Constants.CunddDive.VideoChainPropertyList"];
	
	//	Schema = [self bind:@"vcSettings" toObject:self.qcController withKeyPath:@"patch" options:nil];
	for(NSString * currentKey in bindingKeys){
		NSLog(@"%@",currentKey);
		BOOL bindWithString_value = NO;
		if(bindWithString_value){
			[self.vcSettings bind:currentKey toObject:self.qcController  withKeyPath:[NSString stringWithFormat:@"patch.%@.value",currentKey] options:nil];
			[self.qcController bind:[NSString stringWithFormat:@"patch.%@.value",currentKey] toObject:self.vcSettings withKeyPath:currentKey options:nil];
		} else {
			[self.vcSettings bind:currentKey toObject:self.qcController  withKeyPath:[NSString stringWithFormat:@"patch.%@",currentKey] options:nil];
			[self.qcController bind:[NSString stringWithFormat:@"patch.%@",currentKey] toObject:self.vcSettings withKeyPath:currentKey options:nil];
		}
	//	[self bind:[NSString stringWithFormat:@"vcSettings.%@",currentKey] toObject:self.qcController  withKeyPath:[NSString stringWithFormat:@"patch.%@",currentKey] options:nil];
		
	}
	
	[self.qcController setValue:[NSNumber numberWithInt:1] forKeyPath:@"patch.speed"];
	
	//[self.qcController setValue:@"file://localhost/Users/daniel/Music/iTunes/iTunes%20Music/Movies/Paddles_91-8.mov" forKeyPath:@"patch.movieLocation.value"];
//	[self.vcSettings setValue:@"file://localhost/Users/daniel/Music/iTunes/iTunes%20Music/Movies/Paddles_91-8.mov" forKeyPath:@"movieLocation"];
//	self.vcSettings.movieLocation = @"file://localhost/Users/daniel/Music/iTunes/iTunes%20Music/Movies/Paddles_91-8.mov";


}
@synthesize vcSettings,qcController,vcSettingsController,index,inputController,previewView,vcQCPatchController;
@end
