//
//  CunddMIDI.h
//  MidIn
//
//  Created by Daniel Corn on 15.06.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CoreMIDI/CoreMIDI.h>
#import <CunddMIDI/CunddMIDISource.h>
#import <CunddMIDI/CunddMIDIDevice.h>
#import <CunddMIDI/CunddMIDIDestination.h>
#import <CunddMIDI/CunddMIDIEntity.h>
#import <CunddMIDI/CunddMIDIClient.h>



@interface CunddMIDI : NSObject {

}
/*!
 @method     
 @abstract   Searches for a device with the given unique id
 @discussion Searches for a device with the given unique id
 */
+(id)objectByUniqueId:(NSInteger)theUid;

/*!
    @method     
    @abstract   Outputs all properties of an MIDI object
    @discussion Outputs all properties of an MIDI object
*/
+(void)vardumpMIDIObject:(MIDIObjectRef)theObject;
@end
