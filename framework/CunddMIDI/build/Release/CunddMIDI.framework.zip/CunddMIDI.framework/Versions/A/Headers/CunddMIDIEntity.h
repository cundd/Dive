//
//  CunddMIDIEntity.h
//  MidIn
//
//  Created by Daniel Corn on 14.06.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CoreMIDI/CoreMIDI.h>
#import <CunddMIDI/CunddMIDISource.h>
#import <CunddMIDI/CunddMIDIDestination.h>
#import <CunddMIDI/CunddMIDIDataOwner.h>
#import <CunddCore/CunddAppRegistry.h>



@interface CunddMIDIEntity : CunddMIDIDataOwner {
	MIDIEntityRef entity;
	
	NSString * displayName;
	NSString * name;
	NSString * manufacturer;
	
	NSNumber * deviceId;
	NSNumber * entityUid;
	
	NSMutableArray * sources;
	NSMutableArray * destinations;
}

extern NSString * const kCunddMIDIEntityRegistryCollectionName;

+(void)printCounter;
/*!
    @method     
    @abstract   Returns a new instance with the given Core MIDI entity
    @discussion Returns a new instance with the given Core MIDI entity
*/
+(id)entityWithMIDIEntityRef:(MIDIEntityRef)theEntity;
-(id) initWithEntity:(MIDIEntityRef)theEntity;

/*!
    @method     
    @abstract   Returns the source object at the given index
    @discussion Returns the source object at the given index
*/
-(CunddMIDISource *)sourceAtIndex:(NSUInteger)theIndex;

/*!
 @method     
 @abstract   Returns the destination object at the given index
 @discussion Returns the destination object at the given index
 */
-(CunddMIDIDestination *)destinationAtIndex:(NSUInteger)theIndex;

/*!
 @method     
 @abstract   Returns the first source object
 @discussion Returns the first source object
 */
-(CunddMIDISource *)firstSource;

/*!
 @method     
 @abstract   Returns the first destination object
 @discussion Returns the first destination object
 */
-(CunddMIDIDestination *)firstDestination;



@property (assign) MIDIEntityRef entity;
@property (retain) NSString * displayName;
@property (retain) NSString * name;
@property (retain) NSString * manufacturer;

@property (retain) NSNumber * deviceId;
@property (retain) NSNumber * entityUid;

@property (retain) NSMutableArray * sources;
@property (retain) NSMutableArray * destinations;


@end
