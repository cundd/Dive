//
//  CunddMIDIDataOwner.h
//  MidIn
//
//  Created by Daniel Corn on 17.06.10.
//
//    Copyright © 2010-2012 Corn Daniel
//
//    This file is part of Dive.
//
//    Dive is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    Foobar is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
//
//

#import <Cocoa/Cocoa.h>
#import <CunddMIDI/CunddMIDIObject.h>


@interface CunddMIDIDataOwner : CunddMIDIObject {
	NSMutableData * packetData;
	NSNumber * output;
}

/*!
 @method     
 @abstract   Returns the current data as a dictionary
 @discussion Returns the current data split up into a dictionary with the keys "command", "key" and "velocity"
 */
-(NSDictionary *)dataAsDictionary;


/*!
    @method     
    @abstract   Returns a string of the data in hexadecimal form
    @discussion Returns a string of the data in hexadecimal form
*/
-(NSString *)dataAsString;

/*!
    @method     
    @abstract   Copies the receiver's command value into a given buffer.
    @discussion Copies the receiver's command value into a given buffer.
*/
-(void)getCommand:(Byte **)buffer;

/*!
    @method     
    @abstract   Copies the receiver's key value into a given buffer.
    @discussion Copies the receiver's key value into a given buffer.
*/
-(void)getKey:(Byte **)buffer;

/*!
    @method     
    @abstract   Copies the receiver's velocity value into a given buffer.
    @discussion Copies the receiver's velocity value into a given buffer.
*/
-(void)getVelocity:(Byte **)buffer;

@property (retain) NSMutableData * packetData;
@property (retain) NSNumber * output;

@property (readonly) NSValue * command;
@property (readonly) NSValue * key;
@property (readonly) NSValue * velocity;
@end
