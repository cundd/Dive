//
//  CunddMIDIClient.h
//  MidIn
//
//  Created by Daniel Corn on 12.06.10.
//
//    Copyright © 2010-2012 Corn Daniel
//
//    This file is part of Dive.
//
//    Dive is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    Foobar is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
//
//

#import <Cocoa/Cocoa.h>
#import <CoreMIDI/CoreMIDI.h>
#import <CunddMIDI/CunddMIDIDevice.h>
#import <CunddMIDI/CunddMIDIDataOwner.h>
#import <CunddMIDI/CunddMIDI.h>


@interface CunddMIDIClient : CunddMIDIDataOwner {
	MIDIClientRef midiClient;
	MIDIPortRef inputPort;
	MIDIPortRef outputPort;
	
	CunddMIDISource * sourcePoint;
	CunddMIDIDestination * destinationPoint;
	
	MIDIEndpointRef _destinationPoint;
	MIDIEndpointRef _sourcePoint;
	
	NSMutableArray * devices;
	
	
}


/*!
    @method     
    @abstract   Returns the shared instance
    @discussion Returns the shared instance
*/
+ (CunddMIDIClient *)sharedInstance;

/*!
    @method     
    @abstract   Searches for registered MIDI devices
    @discussion Searches for registered MIDI devices
*/
-(void)rescanDevices;
-(IBAction)rescanDevices:(id)sender;

/*!
    @method     
    @abstract   Called from +sharedInstance
    @discussion Called from +sharedInstance
*/
-(id)_hiddenInit;


/*!
    @method     
    @abstract   Binds a port to a entity
    @discussion Binds a port to a entity
*/
-(OSStatus)bindPortToEntity:(CunddMIDIEntity *)theEntity;


/*!
    @method     
    @abstract   Binds a MIDI object with the given UID
    @discussion Searches for an MIDI object with an given UID and binds it to the clients input port
*/
-(id)bindPortToEntityWithUid:(NSInteger)theUid;


extern NSString * const kCunddMIDIDeviceReceivedData;
extern NSString * const kCunddMIDIDeviceInformationDidChange;

@property (assign) MIDIPortRef inputPort;
@property (assign) MIDIPortRef outputPort;
@property (assign) MIDIClientRef midiClient;


@property (retain) CunddMIDISource * sourcePoint;
@property (retain) CunddMIDIDestination * destinationPoint;
@property (retain) NSMutableArray * devices;
@end
