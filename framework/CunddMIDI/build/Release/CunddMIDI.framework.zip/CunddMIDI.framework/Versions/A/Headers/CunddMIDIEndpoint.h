//
//  CunddMIDIEndpoint.h
//  MidIn
//
//  Created by Daniel Corn on 15.06.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CoreMIDI/CoreMIDI.h>
#import <CunddMIDI/CunddMIDIObject.h>


@interface CunddMIDIEndpoint : CunddMIDIObject {
	MIDIEndpointRef endpoint;
	MIDIPortRef outputPort;
	
	NSData * message;
}

/*!
    @method     
    @abstract   Returns an instance with the given Core Foundation endpoint
    @discussion Returns an instance with the given Core Foundation endpoint
*/
+(id)endpointWithMIDIEndpoint:(MIDIEndpointRef)theEndpoint;


/*!
    @method     
    @abstract   Returns an instance with the given Core Foundation endpoint
    @discussion Returns an instance with the given Core Foundation endpoint
*/
-(id)initWithMIDIEndpoint:(MIDIEndpointRef)theEndpoint;

/*!
 @method     
 @abstract   Sends data of type NSData* to the own destination
 @discussion Sends data of type NSData* to the own destination
 */
-(OSStatus)sendData:(NSData *)data;

/*!
 @method     
 @abstract   Sends the given packetlist to the own destination
 @discussion Sends the given packetlist to the own destination
 */
-(OSStatus)sendMIDIPacketList:(MIDIPacketList *)packetListPointer;

/*!
 @method     
 @abstract   Sends data of type Byte to the own destination
 @discussion Sends data of type Byte to the own destination
 */
-(OSStatus)sendBytes:(Byte *)data;

/*!
 @method     
 @abstract   Sends data of type Byte to the own destination
 @discussion Sends data of type Byte to the own destination
 */
-(OSStatus)sendBytes:(Byte *)data length:(NSUInteger)theLength;

@property (assign) MIDIPortRef outputPort;
@property (assign) MIDIEndpointRef endpoint;

@property (retain) NSData * message;
@end
