//
//  CunddMIDIEndpoint.h
//  MidIn
//
//  Created by Daniel Corn on 15.06.10.
//
//    Copyright © 2010-2012 Corn Daniel
//
//    This file is part of Dive.
//
//    Dive is free software: you can redistribute it and/or modify
//    it under the terms of the GNU General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    (at your option) any later version.
//
//    Foobar is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
//
//

#import <Cocoa/Cocoa.h>
#import <CoreMIDI/CoreMIDI.h>
#import <CunddMIDI/CunddMIDIObject.h>


@interface CunddMIDIEndpoint : CunddMIDIObject {
	MIDIEndpointRef endpoint;
	MIDIPortRef outputPort;
	
	NSData * message;
}

/*!
    @method     
    @abstract   Returns an instance with the given Core Foundation endpoint
    @discussion Returns an instance with the given Core Foundation endpoint
*/
+(id)endpointWithMIDIEndpoint:(MIDIEndpointRef)theEndpoint;


/*!
    @method     
    @abstract   Returns an instance with the given Core Foundation endpoint
    @discussion Returns an instance with the given Core Foundation endpoint
*/
-(id)initWithMIDIEndpoint:(MIDIEndpointRef)theEndpoint;

/*!
 @method     
 @abstract   Sends data of type NSData* to the own destination
 @discussion Sends data of type NSData* to the own destination
 */
-(OSStatus)sendData:(NSData *)data;

/*!
 @method     
 @abstract   Sends the given packetlist to the own destination
 @discussion Sends the given packetlist to the own destination
 */
-(OSStatus)sendMIDIPacketList:(MIDIPacketList *)packetListPointer;

/*!
 @method     
 @abstract   Sends data of type Byte to the own destination
 @discussion Sends data of type Byte to the own destination
 */
-(OSStatus)sendBytes:(Byte *)data;

/*!
 @method     
 @abstract   Sends data of type Byte to the own destination
 @discussion Sends data of type Byte to the own destination
 */
-(OSStatus)sendBytes:(Byte *)data length:(NSUInteger)theLength;

@property (assign) MIDIPortRef outputPort;
@property (assign) MIDIEndpointRef endpoint;

@property (retain) NSData * message;
@end
