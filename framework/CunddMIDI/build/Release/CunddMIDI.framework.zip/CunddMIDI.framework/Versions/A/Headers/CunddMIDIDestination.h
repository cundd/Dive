//
//  CunddMIDIDestination.h
//  MidIn
//
//  Created by Daniel Corn on 15.06.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CunddMIDI/CunddMIDIEndpoint.h>


@interface CunddMIDIDestination : CunddMIDIEndpoint {
}


/*!
    @method     
    @abstract   Returns a new instance with the given output port and MIDI destination
    @discussion Returns a new instance with the given output port and MIDI destination
*/
+(id)destinationWithOutputPort:(MIDIPortRef)theOutputPort andDestination:(MIDIEndpointRef)theDestination;


/*!
 @method     
 @abstract   Returns a new instance with the given output port and MIDI destination
 @discussion Returns a new instance with the given output port and MIDI destination
 */
-(id)initWithOutputPort:(MIDIPortRef)theOutputPort andDestination:(MIDIEndpointRef)theDestination;


@end
