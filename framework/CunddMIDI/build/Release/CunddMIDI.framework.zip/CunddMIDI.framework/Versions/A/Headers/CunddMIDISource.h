//
//  CunddMIDISource.h
//  MidIn
//
//  Created by Daniel Corn on 15.06.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CunddMIDI/CunddMIDIEndpoint.h>

@interface CunddMIDISource : CunddMIDIEndpoint {

}

@end
