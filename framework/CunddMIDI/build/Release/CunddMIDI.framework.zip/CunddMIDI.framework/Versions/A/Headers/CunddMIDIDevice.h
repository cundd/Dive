//
//  CunddMIDIDevice.h
//  MidIn
//
//  Created by Daniel Corn on 14.06.10.
//  Copyright 2010 cundd. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CoreMIDI/CoreMIDI.h>
#import <CunddMIDI/CunddMIDIEntity.h>
#import <CunddMIDI/CunddMIDIObject.h>


@interface CunddMIDIDevice : CunddMIDIObject {
	MIDIDeviceRef _device;
	NSMutableArray * entities;
}
+(id)deviceWithMIDIDeviceRef:(MIDIDeviceRef)theDevice;
-(id) initWithDevice:(MIDIDeviceRef)theDevice;

@property (retain) NSMutableArray * entities;
@end
